# MEERA AI  v2.1.0   (Developed by CH ADiL)

Android app (Kotlin + Jetpack Compose). Package: `com.meera.ai`.
Gemini chat, Gemini Live voice calls, phone automation, coding mode, memory, tools, animated avatar.

> Honest note: this project was written without a compiler. The first build can show small errors -
> paste the first `e:` line and it gets fixed. Nothing here is marked "tested".

## What is new in v2.1 - "Meera Eyes" (camera)
**Open / close (only by your command - the camera never opens by itself):**
- Open: "Meera open your eyes", "aankhein kholo", "meera aankhein khol", "camera on".
- Close: "close your eyes", "aankhein band karo", "meera aankhein band kar", "camera off".
- Works in Chat (typed), the fallback voice call and the Live call. The app matches the words itself (local text match);
  Gemini is not trusted for this. In the Live call the tools `open_eyes` / `close_eyes` exist, but the app opens or closes
  the camera only if YOUR last sentence was a real command (same idea as `confirm_pending`).
- First time: Android asks for the CAMERA permission. Permissions screen shows Camera status + button.

**Eyes screen:** full-screen camera inside the app, red blinking "EYES ON", Close button, front/back switch, small avatar.
Nothing is recorded or saved (no gallery, no files; only in-memory frames). Closes on: close command, Close/Back button,
app going to background, auto-close timer (default 5 min), very hot phone, battery <= 8% (not charging).

**HUD:** every 2.5 s (Settings: 2-5 s) one 640 px JPEG (quality 70) goes to Gemini, which returns up to 8 objects
`{label, category, box_2d}` + a short scene summary. Corner brackets + label chip are drawn over the preview
(human red, animal cyan, plant green, vehicle orange, rest purple), boxes glide between scans and vanish 4 s after they
were last seen. If the previous request is still running the new frame is skipped. A person is only ever labelled
**HUMAN** (forced in code, not only in the prompt): no name, no face recognition, no age, no emotions.

**Questions:** with the eyes ON ask "ye kya hai?" / "isme kya hai?" / "ye kis cheez ka ped hai?" (type or dictate on the
Eyes screen, or speak in a fallback call). The current frame goes to Gemini with your question; Meera answers fully
(what it is, use, interesting facts, caution), in your language, by voice (TTS) and in a text card. Follow-up questions keep the context.
With only "eyes open" and no question, Meera stays silent and just shows the HUD (Settings -> "Continuous description", default OFF).

**Live call + camera:** the Live API accepts video as JPEG frames, max 1 per second (`realtimeInput.video`, per Google's docs).
- Mode **stream** (default): while the eyes are ON about 1 frame/second is sent to the Live session.
- Mode **snapshot**: no video is streamed; for each question the Live model calls the `look_camera` tool, the app takes one
  frame and the chat model answers. Switch in Settings. If the Live server closes the session right after the first
  frame (model without video support) the app switches to snapshot mode by itself and says so.
- What is NOT verified: whether YOUR key / your chosen Live model really accepts video. See `LiveSession.sendVideoFrame`.

**Settings:** scan interval 2-5 s, HUD on/off, default camera, auto-close minutes, continuous description, Live camera mode.

**Updating without uninstalling:** `app/debug.keystore` (fixed key, standard public "android" debug key) is committed and used in
`signingConfigs`. Termux and GitHub Actions builds are signed with the same key, so each new APK installs over the old one.
IMPORTANT: a Meera installed from an OLDER build (signed with some other debug key) must be uninstalled ONCE before 2.1 can
be installed (Android refuses a different signature). Uninstall deletes the app data (API key, memory): note them first.
Never delete or regenerate `app/debug.keystore`, and keep it in the repo (`.gitignore` already allows it).
This key is public: fine for your own phone, NOT for Play Store.

## What was new in v2.0
- **Name:** Yesmin -> **Meera** everywhere (app, package, prompts, scripts).
- **WhatsApp / SMS:** "WhatsApp par Ali ko hello bhejo" / "92300... ko sms karo ...".
  Meera asks "bhej doon? (haan / nahi)". After your "haan" the chat opens with the text typed in and,
  if screen control is ON, the accessibility service taps **Send** (it only taps inside WhatsApp / the SMS app).
  Otherwise you press Send yourself. Android decides whether the tap worked; Meera never claims delivery.
- **Contacts by name:** permission is asked only the first time you use a name. Contacts are searched on the phone only -
  names/numbers are never sent to Gemini.
- **Memory without popups:** Meera asks "yaad rakh loon?" in chat or by voice; you say/type "haan" and she saves it.
  Same for dialer, screen taps and message sending.
- **New Home (tech lab):** menu button (top-left, black/white) -> Memory, Phone automations, Tools & docs, Permissions,
  Settings, About, Owner details. Bottom: Chat (left), Call (center), Code `</>` (right) - icons only.
- **Avatar:** 8 WebP images (normal, happy, excited, sad, loving, thinking, talking, blink), ~50 KB each.
  Chat: Meera adds a hidden `[[MOOD: x]]` tag, the app hides it and changes the face (no tag = normal).
  Call: listening = normal, thinking = thinking, speaking = mouth opens/closes + mood guessed from her words.
  Tap the big avatar on Home to preview the next expression.
- **Lighter build:** ML Kit removed. OCR now uses Gemini vision (works for Hindi/Urdu too; the image you pick is sent to Gemini).

## Build in Termux (copy these one by one)
```
pkg update -y && pkg install -y unzip
termux-setup-storage
cd ~ && unzip -o ~/storage/downloads/MeeraAI.zip
cd MeeraAI && chmod +x gradlew *.sh
termux-wake-lock
sh setup-termux.sh        # one time: Java 17, Gradle 8.7 wrapper, Android SDK 34, aapt2
nohup sh build.sh > build.log 2>&1 &
tail -f build.log
```
The APK is copied to `Downloads/MeeraAI-debug.apk` (also `app/build/outputs/apk/debug/app-debug.apk`).
Install it, open **Settings** and paste your Gemini API key (aistudio.google.com), tap Test, then "Refresh list from Google".

### If Termux closes / "Killed" while building (4 GB phones)
1. Android Settings -> Apps -> Termux -> Battery -> **Unrestricted**. Lock Termux in recent apps.
2. Close all other apps. Developer options -> **Disable child process restrictions** (Android 12+).
3. Lower memory in `gradle.properties`: `-Xmx1536m` -> `-Xmx1100m` and `kotlin.daemon.jvmargs=-Xmx768m`.
4. Run again with the `nohup ... > build.log` line above; finished steps are cached, it continues.
5. Still failing? Build in the cloud (free): put this folder in a GitHub repo, open the **Actions** tab, run
   "Build Meera AI APK", download the artifact `MeeraAI-debug-apk`.

## Settings you may want
- **Chat model / Live model:** names change often. Use "Refresh list from Google". Default Live model: `gemini-3.1-flash-live-preview`.
- **Default country code** (WhatsApp/SMS): for numbers saved without +country code (auto-filled from your SIM, editable).
- **Screen control (Accessibility):** enable the service in Android Settings, then switch ON "Allow screen control"
  on the Phone Automation screen (it resets every time the app starts). Needed for auto-Send and screen reading.

## Permissions
Internet, Microphone (call/dictation), Camera (only for Meera Eyes, asked the first time you say "open your eyes"), Contacts (only when you use a name), Notifications, Set alarm.
Optional (you enable them in Android): Accessibility, Notification access.

## Honest limits
- WhatsApp may change its Send button; if the tap is not found Meera says so and you press Send.
- Live API model names / protocol change; if Live fails the call falls back to recognizer + Gemini + TTS automatically.
- Avatar images have a black background and are shown inside a round frame. Small differences between the
  images (headset, hair clips) are visible when the expression changes.
- No wake-word, no floating bubble, no screen capture.
- The API key is stored with Android Keystore encryption, but an APK can never hide a key completely from a rooted phone.
