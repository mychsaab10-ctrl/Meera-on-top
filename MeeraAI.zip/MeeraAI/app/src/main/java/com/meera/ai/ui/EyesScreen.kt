package com.meera.ai.ui

import androidx.camera.view.PreviewView
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.meera.ai.Meera
import com.meera.ai.eyes.HudBox
import com.meera.ai.voice.CallState
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

private val HudRed = Color(0xFFFF3B3B)
private val HudOrange = Color(0xFFFF9F1C)
private val HudGreen = Color(0xFF34D399)

/** human = red, animal = cyan, plant = green, vehicle = orange, everything else = purple. */
private fun hudColor(category: String): Color = when (category) {
    "human" -> HudRed
    "animal" -> Cyan
    "plant" -> HudGreen
    "vehicle" -> HudOrange
    else -> Purple
}

/**
 * Full-screen "Meera Eyes" camera (lives inside the app, drawn over everything while the eyes are ON).
 * Preview + HUD brackets + answer card. Nothing is recorded or saved.
 */
@Composable
fun EyesScreen() {
    MeeraTheme("dark") {
        EyesContent()
    }
}

@Composable
private fun EyesContent() {
    val eyes = Meera.eyes
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val view = LocalView.current
    val front by eyes.lensFront.collectAsState()
    val boxes by eyes.boxes.collectAsState()
    val summary by eyes.summary.collectAsState()
    val card by eyes.card.collectAsState()
    val busy by eyes.qaBusy.collectAsState()
    val aspect by eyes.frameAspect.collectAsState()
    val callState by Meera.call.state.collectAsState()
    val subs by Meera.call.subtitles.collectAsState()
    val mood by Meera.mood.collectAsState()
    val hudOn = remember { Meera.settings.eyesHud }
    var input by remember { mutableStateOf("") }

    val previewView = remember {
        PreviewView(ctx).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE // TextureView: overlays always draw on top
        }
    }

    // bind the camera while this screen exists; leaving the screen releases it (also on front/back switch)
    DisposableEffect(front) {
        eyes.camera.bind(owner, previewView, front)
        onDispose { eyes.camera.unbind() }
    }
    // app goes to the background -> eyes close
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_STOP) eyes.close("Aankhein band: app background me gayi.") }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    DisposableEffect(Unit) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }

    Surface(Modifier.fillMaxSize(), color = Color.Black, contentColor = Color.White) {
        Box(Modifier.fillMaxSize()) {
            AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())

            if (hudOn) HudOverlay(boxes, aspect, front)

            // ── top bar: avatar + EYES ON + switch + close ──
            Row(
                Modifier.fillMaxWidth().align(Alignment.TopCenter).padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Avatar(44.dp, mood)
                Spacer(Modifier.width(10.dp))
                EyesOnBadge()
                Spacer(Modifier.weight(1f))
                OutlinedButton(
                    onClick = { eyes.lensFront.value = !front },
                    colors = ButtonDefaults.outlinedButtonColors(containerColor = Color(0x99000000), contentColor = Color.White)
                ) { Text(if (front) "🔄 Front" else "🔄 Back", fontSize = 13.sp) }
                Spacer(Modifier.width(8.dp))
                Button(
                    onClick = { eyes.close() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xE6E5484D), contentColor = Color.White)
                ) { Text("✕ Close", fontSize = 13.sp) }
            }

            // ── bottom: scene summary, answer card, question box ──
            Column(
                Modifier.fillMaxWidth().align(Alignment.BottomCenter).padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (callState != CallState.Idle && callState != CallState.Error) {
                    val last = subs.lastOrNull { it.who == "Meera" }?.text.orEmpty()
                    DarkPill("📞 Call on" + if (last.isNotBlank()) "  •  Meera: ${last.takeLast(120)}" else "")
                }
                if (hudOn && summary.isNotBlank() && card == null) DarkPill("👁 $summary")

                card?.let { c ->
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0xE60B0714)).padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(c.question, color = Cyan, fontSize = 12.sp, modifier = Modifier.weight(1f), maxLines = 2)
                            TextButton(onClick = { eyes.stopSpeaking() }) { Text("⏹", fontSize = 13.sp) }
                            TextButton(onClick = { eyes.card.value = null }) { Text("✕", fontSize = 13.sp) }
                        }
                        if (c.busy) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                                Text("Meera dekh rahi hai…", fontSize = 14.sp)
                            }
                        } else {
                            Column(Modifier.heightIn(max = 230.dp).verticalScroll(rememberScrollState())) {
                                Text(c.answer, fontSize = 15.sp, color = Color.White)
                            }
                        }
                    }
                }

                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0xCC000000)).padding(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = input, onValueChange = { input = it },
                        modifier = Modifier.weight(1f), maxLines = 3,
                        placeholder = { Text("Poochho: ye kya hai?", color = Color(0xFFBDB1DA)) }
                    )
                    if (callState == CallState.Idle || callState == CallState.Error) {
                        DictateButton { input = (input + " " + it).trim() }
                    }
                    Button(
                        onClick = { eyes.ask(input); input = "" },
                        enabled = input.isNotBlank() && !busy
                    ) { Text("Send") }
                }
            }
        }
    }
}

@Composable
private fun DarkPill(text: String) {
    Text(
        text, color = Color.White, fontSize = 13.sp, maxLines = 3,
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0xB3000000)).padding(horizontal = 12.dp, vertical = 8.dp)
    )
}

@Composable
private fun EyesOnBadge() {
    val inf = rememberInfiniteTransition(label = "eyesOn")
    val a by inf.animateFloat(0.25f, 1f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "dot")
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(Color(0x99000000)).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(12.dp).clip(CircleShape).background(HudRed.copy(alpha = a)))
        Spacer(Modifier.width(8.dp))
        Text("EYES ON", color = HudRed, fontWeight = FontWeight.Bold, fontSize = 14.sp, letterSpacing = 2.sp)
    }
}

// ───────────── HUD (Iron-Man style brackets) ─────────────

@Composable
private fun HudOverlay(boxes: List<HudBox>, aspect: Float, mirror: Boolean) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val w = constraints.maxWidth.toFloat()
        val h = constraints.maxHeight.toFloat()
        boxes.forEach { b ->
            key(b.id) { HudBoxView(b, aspect, mirror, w, h) }
        }
    }
}

@Composable
private fun HudBoxView(b: HudBox, aspect: Float, mirror: Boolean, w: Float, h: Float) {
    // smooth movement between two scans (same box id = same object)
    val spec = tween<Float>(450, easing = FastOutSlowInEasing)
    val l by animateFloatAsState(b.left, spec, label = "l")
    val t by animateFloatAsState(b.top, spec, label = "t")
    val r by animateFloatAsState(b.right, spec, label = "r")
    val bt by animateFloatAsState(b.bottom, spec, label = "b")
    val alpha by animateFloatAsState(if (b.stale) 0f else 1f, tween(900), label = "a")
    val color = hudColor(b.category)
    val density = LocalDensity.current

    // The preview is FILL_CENTER (cropped), so map frame coordinates -> screen the same way.
    val scale = max(w / aspect, h)
    val dw = aspect * scale
    val dh = scale
    val offX = (w - dw) / 2f
    val offY = (h - dh) / 2f
    val nx1 = if (mirror) 1f - r else l // the front camera preview is mirrored, the analysed frame is not
    val nx2 = if (mirror) 1f - l else r
    val x1 = offX + nx1 * dw
    val x2 = offX + nx2 * dw
    val y1 = offY + t * dh
    val y2 = offY + bt * dh

    Canvas(Modifier.fillMaxSize().alpha(alpha)) {
        val rectW = x2 - x1
        val rectH = y2 - y1
        if (rectW <= 0f || rectH <= 0f) return@Canvas
        drawRect(color.copy(alpha = 0.07f), Offset(x1, y1), Size(rectW, rectH))
        drawRect(color.copy(alpha = 0.30f), Offset(x1, y1), Size(rectW, rectH), style = Stroke(width = 1.dp.toPx()))
        val sw = 3.dp.toPx()
        val c = (min(rectW, rectH) * 0.25f).coerceIn(12.dp.toPx(), 36.dp.toPx())
        fun seg(a: Offset, e: Offset) = drawLine(color, a, e, strokeWidth = sw, cap = StrokeCap.Round)
        seg(Offset(x1, y1), Offset(x1 + c, y1)); seg(Offset(x1, y1), Offset(x1, y1 + c)) // top-left
        seg(Offset(x2, y1), Offset(x2 - c, y1)); seg(Offset(x2, y1), Offset(x2, y1 + c)) // top-right
        seg(Offset(x1, y2), Offset(x1 + c, y2)); seg(Offset(x1, y2), Offset(x1, y2 - c)) // bottom-left
        seg(Offset(x2, y2), Offset(x2 - c, y2)); seg(Offset(x2, y2), Offset(x2, y2 - c)) // bottom-right
    }

    val chipH = with(density) { 22.dp.toPx() }
    val cy = if (y1 - chipH < 0f) y1 else y1 - chipH
    val onChip = if (b.category == "human" || b.category == "other") Color.White else Color.Black
    Text(
        b.label,
        color = onChip, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, maxLines = 1,
        modifier = Modifier
            .offset { IntOffset(x1.roundToInt().coerceAtLeast(0), cy.roundToInt()) }
            .alpha(alpha)
            .clip(RoundedCornerShape(4.dp))
            .background(color.copy(alpha = 0.9f))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    )
}
