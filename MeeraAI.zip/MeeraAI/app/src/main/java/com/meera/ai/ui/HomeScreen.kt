package com.meera.ai.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.meera.ai.Meera
import com.meera.ai.ai.Mood
import com.meera.ai.go
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/** Tech-lab home: menu (top-left), avatar in a HUD ring (center), Chat / Call / Code (bottom, icons only). */
@Composable
fun HomeScreen(nav: NavHostController, onMenu: () -> Unit) {
    val mood by Meera.mood.collectAsState()
    val memories by Meera.memory.items.collectAsState()
    var demo by remember { mutableStateOf<String?>(null) } // tapping the avatar previews the next expression
    LaunchedEffect(demo) { if (demo != null) { delay(4000); demo = null } }
    val shown = demo ?: mood
    val hasKey = Meera.keys.has()

    Column(
        Modifier.fillMaxSize().techLabBackground().padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(46.dp).clip(CircleShape).background(Color.White).clickable { onMenu() },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.Menu, contentDescription = "Menu", tint = Color.Black) }
            Text(
                "MEERA AI", modifier = Modifier.weight(1f), color = Color(0xFFEDE7FF), fontSize = 20.sp,
                fontWeight = FontWeight.Bold, letterSpacing = 5.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            Spacer(Modifier.width(46.dp))
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            LabChip("CORE", if (hasKey) "ONLINE" else "NO KEY", if (hasKey) Color(0xFF34D399) else Pink)
            LabChip("VOICE", if (hasKey) "READY" else "OFF", if (hasKey) Cyan else Pink)
            LabChip("MEMORY", "${memories.size}", Pink)
        }

        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            val d = if (maxWidth < maxHeight) maxWidth else maxHeight
            HudRing(Modifier.size(d * 0.98f))
            Avatar(
                d * 0.68f, shown,
                modifier = Modifier.clickable { demo = Mood.all[(Mood.all.indexOf(shown) + 1) % Mood.all.size] }
            )
        }

        Text("M E E R A", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("AI COMPANION  /  ${if (hasKey) "ONLINE" else "ADD API KEY"}", color = Cyan, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
        Equalizer(Modifier.fillMaxWidth(0.6f).height(34.dp))
        if (!hasKey) {
            Text(
                "Settings me Gemini API key daalo (menu ☰ → Settings).",
                color = Pink, fontSize = 12.sp, modifier = Modifier.clickable { nav.go("settings") }.padding(6.dp)
            )
        }
        Spacer(Modifier.height(6.dp))

        // Dock: Chat (left), Call (center), Code (right) - icons only, no text
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(40.dp)).background(Color(0xE60E0928))
                .border(1.dp, Color(0xFF46388C), RoundedCornerShape(40.dp)).padding(horizontal = 22.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
        ) {
            DockButton("Chat") { nav.go("chat") }
            Box(
                Modifier.size(78.dp).clip(CircleShape)
                    .background(Brush.linearGradient(listOf(Purple, Pink)))
                    .border(3.dp, Pink, CircleShape)
                    .clickable { nav.go("call") },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.Call, contentDescription = "Start call", tint = Color.White, modifier = Modifier.size(36.dp)) }
            DockButton("Code") { nav.go("coding") }
        }
    }
}

@Composable
private fun DockButton(kind: String, onClick: () -> Unit) {
    Box(
        Modifier.size(58.dp).clip(CircleShape).background(Color(0xFF171036)).border(2.dp, Cyan, CircleShape).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        if (kind == "Chat") {
            Canvas(Modifier.size(26.dp)) {
                val w = size.width
                val h = size.height
                drawRoundRect(Cyan, Offset(0f, 0f), Size(w, h * 0.72f), CornerRadius(w * 0.22f), style = Stroke(2.4.dp.toPx()))
                val tail = Path().apply {
                    moveTo(w * 0.22f, h * 0.7f); lineTo(w * 0.16f, h); lineTo(w * 0.52f, h * 0.72f); close()
                }
                drawPath(tail, Cyan)
                for (k in 0..2) drawCircle(Cyan, 1.9.dp.toPx(), Offset(w * (0.3f + 0.2f * k), h * 0.36f))
            }
        } else {
            Text("</>", color = Cyan, fontSize = 19.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        }
    }
}

@Composable
private fun LabChip(label: String, value: String, c: Color) {
    Row(
        Modifier.clip(RoundedCornerShape(10.dp)).background(Color(0xDD10092E))
            .border(1.dp, c.copy(alpha = 0.7f), RoundedCornerShape(10.dp)).padding(horizontal = 8.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Box(Modifier.size(7.dp).clip(CircleShape).background(c))
        Text(label, color = Color(0xFF9E96C8), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        Text(value, color = c, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun Equalizer(modifier: Modifier) {
    val inf = rememberInfiniteTransition(label = "eq")
    val t by inf.animateFloat(0f, (2 * PI).toFloat(), infiniteRepeatable(tween(1800, easing = LinearEasing)), label = "t")
    Canvas(modifier) {
        val n = 27
        val slot = size.width / n
        val bw = slot * 0.55f
        for (i in 0 until n) {
            val amp = (0.2f + 0.8f * abs(sin(t + i * 0.55f))) * (0.4f + 0.6f * abs(cos(i * 0.23f)))
            val hgt = size.height * amp
            val c = if (i < n / 2) Cyan else Pink
            drawRoundRect(c.copy(alpha = 0.9f), Offset(i * slot + (slot - bw) / 2f, (size.height - hgt) / 2f), Size(bw, hgt), CornerRadius(bw / 2f))
        }
    }
}
